import json
import os

meteorites = None
script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, 'y77d-th95.json')
with open(file_path, 'r') as file:
    meteorites = json.load(file)


# Initialize a dictionary to count occurrences of each year
year_counts = {}

# Iterate over each meteorite to count the years
for meteorite in meteorites:
    if 'year' in meteorite and meteorite["year"]:
        # Extract the year part from the "year" field
        year = meteorite["year"][:4]
        # Increment the count for this year
        if year in year_counts:
            year_counts[year] += 1
        else:
            year_counts[year] = 1

# Find the year with the highest count
most_frequent_year = max(year_counts, key=year_counts.get)
most_frequent_count = year_counts[most_frequent_year]

print(f"The most frequent year in the dataset is {most_frequent_year} with {most_frequent_count} occurrences.")