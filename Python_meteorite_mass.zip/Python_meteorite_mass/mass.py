import json
import os

meteorites = None
script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, 'y77d-th95.json')
with open(file_path, 'r') as file:
    meteorites = json.load(file)


# Initialize variables to keep track of the most massive meteorite
max_mass = 0.0  # Use float for mass to handle both integers and floats
most_massive_meteorite = {}

# Function to safely convert a string to a float
def safe_float_conversion(value):
    try:
        return float(value)
    except ValueError:
        return None

# Iterate over each meteorite to find the most massive one
for meteorite in meteorites:
    # Check if the 'mass' key exists
    if 'mass' in meteorite:
        # Safely attempt to convert the mass to a float
        mass = safe_float_conversion(meteorite["mass"])
        # Proceed if the conversion was successful and the mass is greater than the current max
        if mass is not None and mass > max_mass:
            max_mass = mass
            most_massive_meteorite = meteorite

# Check if we found any meteorite with a mass
if most_massive_meteorite:
    # Print the name and mass of the most massive meteorite
    print(f"The most massive meteorite is {most_massive_meteorite['name']} with a mass of {max_mass} grams.")
else:
    print("No meteorite with a valid mass found in the dataset.")